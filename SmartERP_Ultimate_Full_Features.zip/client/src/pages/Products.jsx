
export default function Products(){return <h2>Products Module (Admin Only)</h2>}
