
export default function Purchase(){return <h2>Purchase Order Workflow</h2>}
