
export default function GRN(){return <h2>GRN Workflow (Linked to Purchase)</h2>}
